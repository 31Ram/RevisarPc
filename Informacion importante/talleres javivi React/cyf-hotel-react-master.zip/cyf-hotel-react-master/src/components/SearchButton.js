import React from "react";

const SearchButton = () => {
  return <button className="btn btn-primary">Search</button>;
};

export default SearchButton;
